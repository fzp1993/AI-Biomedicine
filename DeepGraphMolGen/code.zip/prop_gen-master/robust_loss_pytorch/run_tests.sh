python -m robust_loss_pytorch.adaptive_test
python -m robust_loss_pytorch.cubic_spline_test
python -m robust_loss_pytorch.distribution_test
python -m robust_loss_pytorch.fit_partition_spline_test
python -m robust_loss_pytorch.general_test
python -m robust_loss_pytorch.util_test
python -m robust_loss_pytorch.wavelet_test